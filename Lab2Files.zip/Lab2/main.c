#include <msp430.h> 


/**
 * main.c
 */
float b = 10;
unsigned int c = 0b101001010011101;
unsigned int d = 0b101001110101001;

int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	int a = 1;
	a++;
//	b--;
	c << d;
	d << c;
	while(1);
	return 0;
}
