#include <msp430.h> 


/**
 * main.c
 */
int sum(int s1, int s2)
{
    return s1+s2;
}

int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	int a = 0b100011110000000001;
	int b = 0b100011000000000001;
	int d = sum(a,b);
	while(1);
	return 0;
}
